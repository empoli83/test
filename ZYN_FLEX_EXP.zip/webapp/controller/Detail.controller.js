sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_FLEX_EXP.controller.Detail", {

		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("Detail").attachPatternMatched(this.onObjectMatched, this);
			// bu kısımda onObjectMatched in çalışması sağlanıyor.
		},
		onObjectMatched: function(oEvent) {
			var imono = oEvent.getParameter("arguments").Imono;
			
			//buradaki IMONO router daki {Imono} kısmı aynı olmalı
			this.getView().bindElement({
				path: "/GemiTanimSet('" + imono + "')"
			});
		},
		onPressSefer: function(oEvent){
			var imono = oEvent.getSource().getBindingContext().getObject().Imono;
			var gelisno = oEvent.getSource().getBindingContext().getObject().GelisNo;
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "ThreeColumnsMidExpanded");
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/visibleEFull", true);
			
			this.getOwnerComponent().getRouter().navTo("Detail2", {
				Imono: imono,
				Gelisno: gelisno
			});
		},
		middleHandleFullScreen: function(){
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "MidColumnFullScreen");
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/visibleMFull", false);
		},
		middleHandleExitFullScreen: function(){
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/visibleMFull", true);
		},
		middleClose: function(){
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "OneColumn");
		}

	});

});