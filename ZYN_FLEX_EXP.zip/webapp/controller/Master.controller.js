sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_FLEX_EXP.controller.Master", {
		onSearch: function(oEvent) {
			var val = oEvent.getSource().getProperty("value");
			var oFilter = new sap.ui.model.Filter("GemiAdi", sap.ui.model.FilterOperator.Contains, val);

			this.getView().byId("idList").getBinding("items").filter([oFilter]);
		},
		onSelectionChange: function(oEvent) {
			var myimono = oEvent.getSource().getProperty("title").split('-')[1].trim();
			
			
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "TwoColumnsMidExpanded");
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/visibleMFull", true);
			
			this.getOwnerComponent().getRouter().navTo("Detail", {
				Imono: myimono
			});
		},
	});
});