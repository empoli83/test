sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_FLEX_EXP.controller.Detail2", {

		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("Detail2").attachPatternMatched(this.onObjectMatched, this);
			// bu kısımda onObjectMatched in çalışması sağlanıyor.
		},
		onObjectMatched: function(oEvent) {
			var imono = oEvent.getParameter("arguments").Imono;
			var gelisno = oEvent.getParameter("arguments").Gelisno;
			
			this.getView().byId("idImoNo").setText(imono);
			this.getView().byId("idGelisNo").setText(gelisno);
			
			//buradaki IMONO router daki {Imono} kısmı aynı olmalı
			// this.getView().bindElement({
			// 	path: "/GemiTanimSet('" + imono + "')"
			// });
		},
		endHandleFullScreen: function(){
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "EndColumnFullScreen");
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/visibleEFull", false);
		},
		endHandleExitFullScreen: function(){
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "ThreeColumnsMidExpanded");
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/visibleEFull", true);
		},
		endClose: function(){
			this.getOwnerComponent().getModel("FlexibleCoumnLayoutModel").setProperty("/layout", "TwoColumnsMidExpanded");
		}

	});

});