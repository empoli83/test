sap.ui.controller("com.tosyali.egitim.mdZYN_EGITIM_MD.ZYN_MDExt.controller.DetailCustom", {

	extHookGetBaseSelectFields: function() {
		// Place your hook implementation code here 
	}

});