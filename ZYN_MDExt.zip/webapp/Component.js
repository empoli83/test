jQuery.sap.declare("com.tosyali.egitim.mdZYN_EGITIM_MD.ZYN_MDExt.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "com.tosyali.egitim.mdZYN_EGITIM_MD",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/ZYN_MD"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.com.tosyali.egitim.mdZYN_EGITIM_MD.Component.extend("com.tosyali.egitim.mdZYN_EGITIM_MD.ZYN_MDExt.Component", {
	metadata: {
		manifest: "json"
	}
});