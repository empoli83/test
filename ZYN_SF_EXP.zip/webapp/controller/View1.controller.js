sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_SF_EXP.controller.View1", {
		
		onPressPdf: function(){
			var c = this.byId("idInpCustomer").getValue();
			var sPath = "http://10.80.1.242:8000/sap/opu/odata/sap/ZSMARTFORMS_PDF_SRV/PdfSet('" + c + "')/$value";
			var link = document.createElement('a');
			link.href = sPath;
			link.download = c + ".pdf";
			link.click();
		}
		
	});
});