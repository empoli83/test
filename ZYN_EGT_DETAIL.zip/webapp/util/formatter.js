sap.ui.define([], function() {
	"use strict";

	return {

		convertFaaliyet: function(val){
			if(val){
				switch(val){
					case 'Y':
						return "Yükleme";
					case 'B':
						return "Boşaltma";
				}
			}
			return val;
		},
		visibleMessagePopover: function(val){
			if(val){
				if(val > 0){
					return true;
				}else{
					return false;
				}
			}
			return false;
		}

	};
});