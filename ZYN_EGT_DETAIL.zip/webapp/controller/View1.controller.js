sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"../util/formatter"
], function(Controller,History,MessageBox,MessageToast,formatter) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_EGT_DETAIL.controller.View1", {
		myFormatter : formatter,
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("Detail").attachPatternMatched(this.onObjectMatched, this);
			// bu kısımda onObjectMatched in çalışması sağlanıyor.
		},
		onObjectMatched: function(oEvent) {
			var imono = oEvent.getParameter("arguments").imono;
			//buradaki IMONO router daki {Imono} kısmı aynı olmalı
			this.getView().bindElement({
				path: "/GemiTanimSet('" + imono + "')"
			});
		},
		onNavBack: function(){
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getOwnerComponent().getRouter().navTo("Master");
			}
		},
		onEditGemiTanim: function(){
				this.getOwnerComponent().getModel("appModel").setProperty("/mode", "edit");
				
				var sObjectPath = this.getView().getElementBinding().getPath();///this.getView().getBindingContext().getPath();
				this.getOwnerComponent().getRouter().getTargets().display("Create_Edit",{
					sPath : sObjectPath
				});
		},
		
		onEditGemiTanim2: function(){
				this.getOwnerComponent().getModel("appModel").setProperty("/mode", "edit");
				
				var sObjectPath = this.getView().getElementBinding().getPath();///this.getView().getBindingContext().getPath();
				this.getOwnerComponent().getRouter().getTargets().display("Create_Edit2",{
					mode:"edit",
					sPath : sObjectPath
				});
		},
		
		onDeleteGemiTanim: function(){
			var that = this;
			MessageBox.show("Silmek istediğinize emin misiniz?", {
				icon: "sap-icon://question-mark",
				title: "Uyarı",
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.OK) {
						var sPath = that.getView().getElementBinding().getPath();
						
						that.getOwnerComponent().getModel().remove(sPath, {
							success: function(data){
								MessageToast.show("işlem başarılı..");
								that.getOwnerComponent().getModel("appModel").setProperty("/firstRun","1");
							},
							error: function(err){
								MessageBox.error(JSON.parse(err.responseText).error.message.value);
							}
						});
					}
				}
			});
			
		}
	});
});