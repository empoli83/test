sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_TREE_EXP.controller.View1", {
		
		onInit: function() {
			var oTable = this.getView().byId("treeTable");
			var oTable2 = this.getView().byId("treeTable2");
			
			//navigation service
			var sServiceUrl = "/sap/opu/odata/sap/ZLIMAN_TREE_SRV/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, { useBatch : true });
			oTable.setModel(oModel);
			oTable2.setModel(oModel);

			//navigation service binding
			oTable.bindRows({
				path: "/DurusNedenSet",
				parameters: {
					treeAnnotationProperties : {
                    hierarchyLevelFor : 'level',
                    hierarchyNodeFor : 'id',
                    hierarchyParentNodeFor : 'parent_id',
                    hierarchyDrillStateFor : 'drill_state'
                }
				}
			});
			
			oTable2.bindRows({
				path:'/NodesSet',
				parameters:{
					 expand : "ToNodes",
					 navigation : {
					 'NodesSet' : 'ToNodes'
					 }
				}
			});
			
		}
		
	});
});