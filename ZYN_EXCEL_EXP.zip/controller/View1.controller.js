sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function(Controller, Export, ExportTypeCSV) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_EXCEL_EXP.controller.View1", {
		onPressExcelSablonuIndir: function() {

			var path = "http://tscisksapt12.tosyali.local:50000/sap/bc/bsp/sap/public/Excel/Rapor.xls?sap-client=200";
			path = "http://tscisksappfio.tosyali.local:8000/sap/bc/bsp/sap/public/Excel/Rapor.xls";
			var link = document.createElement('a');
			link.href = path;
			link.download = "Rapor.xls";
			link.click();
		},
		onInit: function() {
			this.sikayetModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this.sikayetModel, "sikayetler");
		},
		onUploadExcelFile: function(e) {
			this._import(e.getParameter("files") && e.getParameter("files")[0]);
		},
		_import: function(file) {
			var that = this;
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function(e) {
					var data = e.target.result;
					var workbook = XLSX.read(data, {
						type: 'binary'
					});
					workbook.SheetNames.forEach(function(sheetName) {
						// Here is your object for every sheet in workbook
						excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);

					});
					// Setting the data to the local model 
					that.sikayetModel.setData(excelData);
					that.sikayetModel.refresh(true);
				};
				reader.onerror = function(ex) {
					console.log(ex);
				};
				reader.readAsBinaryString(file);
			}
		},
		onPressExportToExcel: function() {
			var oExport = new sap.ui.core.util.Export({
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: ";"
				}),
				models: this.sikayetModel,
				rows: {
					path: "/"
				},
				columns: [{
					name: "Kayıt No",
					template: {
						content: "{Kayit_No}"
					}
				}, {
					name: "Durum",
					template: {
						content: "{Durum}"
					}
				}, {
					name: "Müşteri",
					template: {
						content: "{Musteri}"
					}
				}, {
					name: "Şikayet Tanımı",
					template: {
						content: "{Sikayet_Tanimi}"
					}
				}, {
					name: "Kaydı Açan",
					template: {
						content: "{Kaydi_Acan}"
					}
				}, {
					name: "Kategori",
					template: {
						content: "{Kategori}"
					}
				}]
			});
			// download exported file
			oExport.saveFile().always(function() {
				this.destroy();
			});

		}
	});
});