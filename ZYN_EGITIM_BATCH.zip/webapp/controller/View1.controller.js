sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_EGITIM_BATCH.controller.View1", {
		
		onInit: function(){
			
			this.updatedGemiler = [];
			this.newGemiler = [];
			this.deletedGemiler = [];
			
			this.oDataModel = this.getOwnerComponent().getModel();
			var jModel = new sap.ui.model.json.JSONModel();
			
			var that = this;
			
			this.oDataModel.read("/GemiTanimSet?$top=10",{
				// parameters: {
				// 	$top : 10
				// },
				success: function(data){
					jModel.setData(data.results);
					that.getView().setModel(jModel,"gemiler");
				},
				error: function(err){
					
				}
			});
			
		},
		enableDisableCellsOfSelectedRow: function(oEvent,val){
			oEvent.getSource().getParent("cells").getCells()[1].setEnabled(val);
			oEvent.getSource().getParent("cells").getCells()[2].setEnabled(val);
			oEvent.getSource().getParent("cells").getCells()[3].setEnabled(val);
			oEvent.getSource().getParent("cells").getCells()[4].setEnabled(val);
			oEvent.getSource().getParent("cells").getCells()[5].setEnabled(val);
			oEvent.getSource().getParent("cells").getCells()[6].setEnabled(!val);
			oEvent.getSource().getParent("cells").getCells()[7].setEnabled(val);
			oEvent.getSource().getParent("cells").getCells()[8].setEnabled(!val);
		},
		onEditRow: function(oEvent){
			this.enableDisableCellsOfSelectedRow(oEvent, true);
		},
		onSaveRow: function(oEvent){
			this.enableDisableCellsOfSelectedRow(oEvent, false);
			var gemi = oEvent.getSource().getBindingContext("gemiler").getObject();
			this.updatedGemiler.push(gemi);
		},
		onDeleteRow: function(oEvent){
			var gemi = oEvent.getSource().getBindingContext("gemiler").getObject();
			this.deletedGemiler.push(gemi);
			
			var index = Number(oEvent.getSource().getBindingContext("gemiler").getPath().substring(1));
			var jModel = this.getView().getModel("gemiler");
			
			var gemiler = jModel.getData();
			gemiler.splice(index,1);
			
			jModel.setData(gemiler);
			this.getView().setModel(jModel,"gemiler");
		},
		openGemiDialog: function(){
			if (!this.gemiDialog) {
				this.gemiDialog = sap.ui.xmlfragment(this.getView().getId(), "com.tosyali.egitimZYN_EGITIM_BATCH.view.fragments.yenigemi", this); 
			}
			this.gemiDialog.open();
		},
		onCloseDialog: function(){
			this.gemiDialog.close();
		},
		onAddGemi : function(){
			var oEntry = {};
			oEntry.Imono = this.getView().byId("idImoNo").getValue();
			oEntry.GemiAdi = this.getView().byId("idGemiAdi").getValue();
			oEntry.GemiEskiAdi = this.getView().byId("idGemiEskiAdi").getValue();
			oEntry.Armator = this.getView().byId("idArmator").getValue();
			oEntry.Bayrak = this.getView().byId("idBayrak").getValue();
			oEntry.YapimYili = this.getView().byId("idYapimYili").getValue();
			
			this.newGemiler.push(oEntry);
			
			var jModel = this.getView().getModel("gemiler");
			var gemiler = jModel.getData();
			gemiler.push(oEntry);
			jModel.setData(gemiler);
			this.getView().setModel(jModel,"gemiler");
		},
		onPressKaydet: function(){
		//	this.oDataModel.setUseBatch(true);
			this.oDataModel.setDeferredGroups(["myGemiler"]);
			
			for(var i = 0 ; i < this.newGemiler.length ; i++){
				this.oDataModel.create("/GemiTanimSet",this.newGemiler[i], {groupId:"myGemiler"});
			}
			for(i = 0 ; i < this.updatedGemiler.length ; i++){
				var gemi = this.updatedGemiler[i];
				this.oDataModel.update("/GemiTanimSet('"+ gemi.Imono +"')", gemi, {groupId:"myGemiler"});
			}
			
			for(i = 0 ; i < this.deletedGemiler.length ; i++){
				var dgemi = this.deletedGemiler[i];
				this.oDataModel.remove("/GemiTanimSet('"+ dgemi.Imono +"')",  {groupId:"myGemiler"});
			}
			
			
			this.oDataModel.submitChanges();
			
		}
	});
});