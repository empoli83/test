sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/MessageType",
	"../util/formatter"
], function(Controller,MessageBox,MessageToast, MessageType,formatter) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_EGITIM_FB.controller.Main", {
		myFormatter: formatter,
		
		onInit: function(){
			var jModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(jModel,"viewModel");
			
			var mModel =  new sap.ui.model.json.JSONModel();
			mModel.setData([]);
			this.getView().setModel(mModel,"messages");
			
		},
		onPressMessagePopover: function(oEvent){
			if (!this._oMessagePopover) {
				this._oMessagePopover = sap.ui.xmlfragment(this.getView().getId(),
					"com.tosyali.egitimZYN_EGITIM_FB.view.fragments.MessagePopover", this);
				this.getView().addDependent(this._oMessagePopover);
			}
			this._oMessagePopover.openBy(oEvent.getSource());
		},
		openUlkelerSH: function(oEvent) {
			if (!this.ulkeSHDialog) {
				this.ulkeSHDialog = sap.ui.xmlfragment("com.tosyali.egitimZYN_EGITIM_FB.view.fragments.ulkeler", this);
				this.getView().addDependent(this.ulkeSHDialog); //ulke diyalog Main.controller'ı kullansın diye
			}
			this.ulkeSHDialog.open();
		},
		pressUlkeSearchHelp : function(oEvent){
			var val = oEvent.getParameter("value");
			
			var myfilter = new sap.ui.model.Filter("LANDX", sap.ui.model.FilterOperator.Contains, val);
			
			oEvent.getSource().getBinding("items").filter([myfilter]);
		},
		handleUlkeHelpClose: function(oEvent){
			var sItem = oEvent.getParameter("selectedItem");
			if(sItem){
				this.byId("idUlke").setValue(sItem.getTitle());
			}
		},
		onSearch : function(){
			this.getView().getModel("viewModel").setProperty("/busy",true);
			
			var ulke = this.byId("idUlke").getValue();
			ulke = ulke.split("-")[0];
			
			var that = this;
			
			var msgModel = this.getView().getModel("messages");
			var messages = [];
			
			var jModel = new sap.ui.model.json.JSONModel();
			
			var myFilters = [];
			myFilters.push(new sap.ui.model.Filter("Bayrak", sap.ui.model.FilterOperator.EQ, ulke));
			
			this.getOwnerComponent().getModel().read("/GemiTanimSet",{
				filters: myFilters,
				success: function(data){
					that.getView().getModel("viewModel").setProperty("/busy",false);
					
					jModel.setData(data.results);
					that.getOwnerComponent().setModel(jModel, "gemiler");
					if(data.results.length == 0){
						//MessageBox.error("Kayıt bulunamadı..");
						messages.push({
							type: MessageType.Warning,
							title: "Kayıt bulunamadı",
							additionalText: "hata var"
						});
						messages.push({
							type: MessageType.Error,
							title: "Kayıt bulunamadı"
						});
						
						msgModel.setData(messages);
						msgModel.setProperty("/numberOfMessages", messages.length);
						
						that.getView().setModel(msgModel, "messages");
						
					}else{
						MessageToast.show(data.results.length + " adet kayıt bulundu");
						
						msgModel.setData([]);
						msgModel.setProperty("/numberOfMessages", 0);
						that.getView().setModel(msgModel, "messages");
					}
				},
				error: function(err){
					that.getView().getModel("viewModel").setProperty("/busy",false);
					MessageBox.error(JSON.parse(err.responseText).error.message.value);
				}
			});
			
		},
		onPressImono: function(oEvent){
			var myimono = oEvent.getSource().getTitle();
			
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "md",
						action: "display"
					},
					params: {
						"imono": myimono
					}
				});
			} else {
				//alert("App to app navigation is not supported in this mode");  
			}
			
			
			// this.getOwnerComponent().getRouter().navTo("Seferler", {
			// 	imono: myimono
			// });
		}
	});
});