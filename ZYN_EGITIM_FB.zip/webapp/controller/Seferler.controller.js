sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../util/formatter"
], function(Controller,formatter) {
	"use strict";

	return Controller.extend("com.tosyali.egitimZYN_EGITIM_FB.controller.Seferler", {
		
		myFormatter : formatter,
		
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("Seferler").attachPatternMatched(this.onObjectMatched, this);
		},
		onObjectMatched: function(oEvent) {
			var imono = oEvent.getParameter("arguments").imono;

			this.getView().bindElement({
				path: "/GemiTanimSet('" + imono + "')"
			});
			
		}
		// convertFaaliyet: function(val){
		// 	if(val){
		// 		switch(val){
		// 			case 'Y':
		// 				return "Yükleme";
		// 			case 'B':
		// 				return "Boşaltma";
		// 		}
		// 	}
		// 	return val;
		// }
	});

});