sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(Controller,MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("com.tosyali.egitim.mdZYN_EGITIM_MD.controller.Create_Edit2", {

		onInit: function() {
			this.oDataModel = this.getOwnerComponent().getModel();
			this.getOwnerComponent().getRouter().getTargets().getTarget("Create_Edit2").attachDisplay(null, this._onDisplay, this);
		},
		_onDisplay: function(oEvent) {
			var that = this;
			
			var mode = oEvent.getParameter("data").mode;
			if (mode === "edit") {
				var oData = oEvent.getParameter("data");
				this.getView().bindElement({
					path: oData.sPath
				});
			} else {

			var oContext = this.oDataModel.createEntry("GemiTanimSet", {
					success: function(data) {
						that.getOwnerComponent().getRouter().navTo("Detail", {
							imono: data.Imono
						});
					},
					error: function() {

					}
				});
				this.getView().setBindingContext(oContext);
			}
		},
		onPressKaydetGuncelle: function() {

			if(!this.oDataModel.hasPendingChanges()){
				MessageBox.error("Bekleyen bir değişiklik yok..");
				return;
			}
			
			var that = this;
			
			this.oDataModel.attachEventOnce("batchRequestCompleted",function(oEvent){
				if(that.checkIfSuccessfull(oEvent)){
					that.getView().unbindObject();
					that.getOwnerComponent().getRouter().getTargets().display("Detail");
					MessageToast.show("İşlem başarılı");
				}
			});
			this.oDataModel.submitChanges();
		},
		checkIfSuccessfull: function(oEvent){
			var params = oEvent.getParameters();
			var requests = params.requests;
			if(params.success){
				for(var i = 0 ; i < requests.length ; i++){
					if(!requests[i].success){
						return false;
					}
				}
			}
			
			return true;
		}

	});

});