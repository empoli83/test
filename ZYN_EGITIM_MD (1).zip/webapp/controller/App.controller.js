sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.tosyali.egitim.mdZYN_EGITIM_MD.controller.App", {
		
		onInit: function(){
		}
		
	});
});