sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(Controller, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("com.tosyali.egitim.mdZYN_EGITIM_MD.controller.Create_Edit", {

		onInit: function() {
			this.oDataModel = this.getOwnerComponent().getModel();
			this.getOwnerComponent().getRouter().getTargets().getTarget("Create_Edit").attachDisplay(null, this._onDisplay, this);
		},
		_onDisplay: function(oEvent) {
			var mode = this.getOwnerComponent().getModel("appModel").getProperty("/mode");
			if (mode === "edit") {
				var oData = oEvent.getParameter("data");
				this.getView().bindElement({
					path: oData.sPath
				});
			}

		},

		validateInputs: function() {
			var imono = this.getView().byId("idImoNo").getValue();
			if (imono.length !== 7) {
				this.getView().byId("idImoNo").setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				this.getView().byId("idImoNo").setValueState(sap.ui.core.ValueState.None);
			}

			return true;
		},
		onPressKaydetGuncelle: function() {

			if (!this.validateInputs()) {
				return;
			}

			var oEntry = {};
			oEntry.Imono = this.getView().byId("idImoNo").getValue();
			oEntry.GemiAdi = this.getView().byId("idGemiAdi").getValue();
			oEntry.Armator = this.getView().byId("idArmator").getValue();
			oEntry.Bayrak = this.getView().byId("idBayrak").getValue();
			oEntry.YapimYili = this.getView().byId("idYapimYili").getValue();

			var that = this;

			var mode = this.getOwnerComponent().getModel("appModel").getProperty("/mode");
			if (mode === "create") {

				var jModel = this.getOwnerComponent().getModel("gemiseferleri");
				if (jModel){
					var myseferler = jModel.getData();
					oEntry.Seferler = myseferler;
				}

				this.oDataModel.create("/GemiTanimSet", oEntry, {
					success: function(data) {
						MessageToast.show("Kayıt işlemi başarılı..");
						that.getOwnerComponent().getRouter().navTo("Detail", {
							imono: oEntry.Imono
						});
					},
					error: function(err) {
						MessageBox.error(JSON.parse(err.responseText).error.message.value);
					}
				});
			} else {
				var sObjectPath = this.getView().getElementBinding().getPath();

				this.oDataModel.update(sObjectPath, oEntry, {
					success: function(data) {
						MessageToast.show("Güncelleme işlemi başarılı..");
						that.getOwnerComponent().getRouter().getTargets().display("Detail");
						//history.go(-1);
						// that.getOwnerComponent().getRouter().navTo("Detail", {
						// 	imono: oEntry.Imono
						// });
					},
					error: function(err) {
						MessageBox.error(JSON.parse(err.responseText).error.message.value);
					}
				});
			}
		},
		openGemiDialog: function() {
			if (!this.seferDialog) {
				this.seferDialog = sap.ui.xmlfragment(this.getView().getId(), "com.tosyali.egitim.mdZYN_EGITIM_MD.view.fragments.NewSefer", this);
				//	this.getView().addDependent(this.ulkeSHDialog); //ulke diyalog Main.controller'ı kullansın diye
			}
			this.seferDialog.open();
		},
		onCloseDialog: function() {
			this.seferDialog.close();
		},
		onAddSefer: function() {
			var sefer = {};
			sefer.GelisNo = this.getView().byId("idGelisNo").getValue();
			sefer.Faaliyet = this.getView().byId("idFaaliyet").getValue();
			sefer.Yuktipi = this.getView().byId("idYukTipi").getValue();
			sefer.Liman = this.getView().byId("idLiman").getValue();
			sefer.Acenta1 = this.getView().byId("idAcenta1").getValue();
			sefer.TahYanTar = this.getView().byId("idYanasmaTarihi").getDateValue();
			//sefer.TahYanSaat = this.getView().byId("idYanasmaSaati").getValue();

			var seferler = [];
			var jModel = this.getOwnerComponent().getModel("gemiseferleri");
			if (jModel) {
				seferler = jModel.getData();
			} {
				jModel = new sap.ui.model.json.JSONModel();
			}

			seferler.push(sefer);
			jModel.setData(seferler);
			this.getOwnerComponent().setModel(jModel, "gemiseferleri");

			this.onCloseDialog();
		}

	});

});