jQuery.sap.declare("testzyn_lr_test_1.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("testzyn_lr_test_1.Component", {
	metadata: {
		"manifest": "json"
	}
});