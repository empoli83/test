/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.zyn.ui5.library.zyn_ui5_library.
 */
sap.ui.define(["sap/ui/core/library"], // library dependency
	function () {

		"use strict";

		/**
		 * 
		 *
		 * @namespace
		 * @name zyn_lib
		 * @author SAP SE
		 * @version 1.0.0
		 * @public
		 */
		 sap.ui.getCore().initLibrary({
			name: "zyn_ui5_lib",
			version: "1.0.0",
			dependencies: ["sap.ui.core"],
			types: [],
			interfaces: [],
			controls: ["zyn_ui5_lib.controls.ToplantiObjectHeader"],
			elements: []
		});

		

		/* eslint-disable */
		return zyn_ui5_lib;
		/* eslint-enable */

	}, /* bExport= */ false);