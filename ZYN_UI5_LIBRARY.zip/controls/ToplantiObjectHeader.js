/*!
 * ${copyright}
 */

// Provides control com.zyn.ui5.library.zyn_ui5_library.
sap.ui.define(['jquery.sap.global', './../library', 'sap/ui/core/Control'],
	function (jQuery, library, Control) {
		"use strict";

		/**
		 * Constructor for a new PersonelObjectHeader Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  Control
		 *
		 * @author SAP SE
		 * @version 1.0.0
		 *
		 * @constructor
		 * @public
		 * @alias zyn_lib.controls.PersonelObjectHeader
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oToplantiObjectHeader = sap.m.Page.extend("zyn_ui5_lib.controls.ToplantiObjectHeader", {
			metadata: {

				library: "zyn_ui5_lib",
				properties: {
					topno: {
						type: "string"
					},
					KonuVisibility: {
						type: "boolean",
						defaultValue: true
					},
					YerVisibility: {
						type: "boolean",
						defaultValue: true
					}

				},
				events: {

					/**
					 * Event is fired when the user clicks on the control.
					 */
					press: {}

				}
			}
		});

		return oToplantiObjectHeader;

	}, /* bExport= */ true);