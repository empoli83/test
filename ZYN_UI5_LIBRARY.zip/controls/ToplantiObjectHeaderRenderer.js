/*!
 * ${copyright}
 */

sap.ui.define(['jquery.sap.global',"sap/m/PageRenderer"],

	function (jQuery,PageRenderer) {
		"use strict";

		/**
		 * PersonelObjectHeader renderer.
		 * @namespace
		 */
		var ToplantiObjectHeaderRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param Control oControl
		 *            the control to be rendered
		 */
		ToplantiObjectHeaderRenderer.render = function (oRm, oControl) {
			var jModel = new sap.ui.model.json.JSONModel();
			//var that = this;
			var serviceUrl = "/sap/opu/odata/sap/ZBHB004_SRV/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);
			var topno = oControl.getTopno();
			
			oModel.read("/ToplantiSet('" + topno + "')", {
				success: function (data) {
					jModel.setData(data);
					oControl.setModel(jModel, "toplanti");
				},
				error: function () {
				}
			});
			
			var w = sap.ui.xmlfragment(oControl.getId(), "zyn_ui5_lib.fragments.toh", this);
			oControl.addContent(w);
			
			var controlModel = new sap.ui.model.json.JSONModel();
			controlModel.setProperty("/KonuVisibility1", oControl.getKonuVisibility());
			controlModel.setProperty("/YerVisibility1", oControl.getYerVisibility());
			oControl.setModel(controlModel,"control");
			
			oControl.setShowHeader(true);
			
			PageRenderer.render(oRm, oControl);

		};

		return ToplantiObjectHeaderRenderer;

	}, /* bExport= */ true);